// cammand to run: "php parser.php --file examples/test.csv --unique-combinations=results.csv"
// -file : its is a required argument which contain the path of the CSV file to be scan
// --unique-combinations : it is an option argurment which contain the path where the Grouping of common row will be found


<?php

$time_start = microtime(true);
$mem_start = memory_get_usage();
//read the csv file into an array

$header = array("make", "model", "colour", "capacity", "network", "grade", "condition");

$short_options = "-combinations";
$long_options = ["file:", "unique-combinations::"];
$options = getopt($short_options, $long_options);

if (isset($options["file"])) {
    $file = $options["file"];
    if (pathinfo($file, PATHINFO_EXTENSION) == "csv") {
        $group = csvToArray($header, $file);
    } else {
        assert("THIS FILE FORMAT NOT TAKEN INTO ACCOUNT PLEASE CHOOSE CORRECT FILE");
    }

    if (isset($options["unique-combinations"])) {
        $save_file = $options["unique-combinations"];
        saveGroup($group, $save_file, $header);
    }
} else {
    echo "enter the file name";
}

$time_end = microtime(true);
$mem_end = memory_get_usage();
$execution_time = ($time_end - $time_start) / 60;
$execution_mem = ($mem_end - $mem_start) / 1024;
//execution time of the script
echo 'Total Execution Time: ' . $execution_time . 'mins';
echo '  Total memory used: ' . $execution_mem . ' Mb';
// if you get weird results, use number_format((float) $execution_time, 10) 


function csvToArray($header, $csvFile)
{

    $file_to_read = fopen($csvFile, 'r');
    $list = array();
    $CurrentRow = -1;
    while (($data = fgetcsv($file_to_read, 1000, ',')) !== FALSE) {
        $CurrentRow++;
        if ($CurrentRow < 1) {
            continue;
        }

        $relation = array();
        for ($i = 0; $i < count($data); $i++) {
            $relation[$header[$i]] = trim($data[$i]);
        }
        $index = findRow($relation, $list);
        if ($index == -1) {
            $elt = array_push($list, $relation);
            $list[$elt - 1]["count"] = 1;
        } else if ($index > -1) {
            $list[$index]["count"] = $list[$index]["count"] + 1;
        }

        echo json_encode($relation), PHP_EOL;
        echo PHP_EOL;
        unset($relation);
    }

    fclose($file_to_read);
    return $list;
}

function findRow($row, $array)
{
    $state = true;
    $result = -1;
    for ($i = 0; $i < count($array); $i++) {
        foreach ($array[$i] as $key => $value) {
            if ($key !== "count") {
                if ($row[$key] !== $value) {
                    $state = false;
                    break;
                }
            }
        }
        if ($state) {
            $result = $i;
            break;
        } else {
            $state = true;
        }
    }

    return $result;
}

function saveGroup($group, $file, $header)
{

    $fp = fopen($file, 'w');
    fputcsv($fp, array_merge($header, array("count"),));
    foreach ($group as $fields) {
        fputcsv($fp, $fields);
    }
}
